# Ticket API With Node, Express and MySql (using Sequelize)

Have fun! 😄

## Run

    docker-compose up --build

## Test

npm run test


