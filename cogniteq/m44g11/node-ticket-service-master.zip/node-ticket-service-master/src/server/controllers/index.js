const tickets = require("./tickets");

module.exports = {
  tickets,
};
